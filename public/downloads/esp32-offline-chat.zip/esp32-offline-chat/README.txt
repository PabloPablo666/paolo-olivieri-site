ESP32 Offline Chat (Operation Houghton)

- Board: ESP32
- Mode: Wi-Fi SoftAP + HTTP server
- Endpoints: /, /send (POST), /chatlog
- Note: chat log is volatile (RAM). Polling refresh on client side.
